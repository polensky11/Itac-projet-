#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
     printf("********************* CALCULATRICE ***************************** \n\n\n\n");
    bool on = true;
    char operation ;
    char percent = '%';
    float nombre1 = 0, nombre2 = 0;

    printf(" quelle operation voulez vous effectuez ? \n\n");
    printf("- LISTE \n\n");
    printf(".     + -> addition \n");
    printf(".     - -> soustraction \n");
    printf(".     / -> division \n");
    printf(".     * -> multiplication \n");
    printf(".     %c -> reste de la division \n", percent);
    printf(".     ^ -> puissance \n");
    printf(".     ! -> factorielle \n");
    printf(".     g -> PGCD \n");
    printf(".     p -> PPMC \n\n\n");
    printf(".     q -> pour fermer la clculatrice \n\n\n");


    while(on){
            printf(" votre choix d'operation : ");
            scanf("%c", &operation);

            // addition
            if(operation == '+'){
                printf("entrez le premier nombre :");
                scanf("%f",&nombre1);
                printf("entrez le segond nombre : ");
                scanf("%f",&nombre2);

                printf("resultat : %f \n\n\n",nombre1 + nombre2);
            }

            //soustraction
            else if(operation == '-'){
                printf("entrez le premier nombre :");
                scanf("%f",&nombre1);
                printf("entrez le segond nombre : ");
                scanf("%f",&nombre2);

                printf("resultat : %f \n\n\n",nombre1 - nombre2);
                scanf("%c", &operation);
            }

            //division
            else if(operation == '/'){
                printf("entrez le premier nombre :");
                scanf("%f",&nombre1);
                printf("entrez le segond nombre : ");
                scanf("%f",&nombre2);

                printf("resultat : %f \n\n\n",nombre1 / nombre2);
            }

            //multiplication
            else if(operation == '*'){
                printf("entrez le premier nombre :");
                scanf("%f",&nombre1);
                printf("entrez le segond nombre : ");
                scanf("%f",&nombre2);

                printf("resultat : %f \n\n\n",nombre1 * nombre2);
            }

            //puissance
            else if(operation == '^'){
                printf("entrez le premier nombre :");
                scanf("%f",&nombre1);
                printf("entrez le segond nombre : ");
                scanf("%f",&nombre2);

                if(nombre2 == 0){
                  printf("resultat : 1 \n\n\n");
                }
                else if(nombre2 > 0){
                    float result = 1;
                    for(int i = 0; i < nombre2; i++){
                        result = result * nombre1;
                    }
                    printf("resultat : %f \n\n\n",result);
                }
                else if(nombre2 < 0){
                    float result = 1;
                    for(int i = 0; i > nombre2; i--){
                        result = result * nombre1;
                    }
                    printf("resultat : 1 / %f \n\n\n", result);
                }
            }


            //factorielle
            else if(operation == '!'){
                printf("entrez le nombre :");
                scanf("%f",&nombre1);

                nombre1 = (int)nombre1;
                float result = 1;
                while(nombre1 > 0){
                    result = result * nombre1;
                    nombre1--;
                }
                printf("resultat : %f \n\n\n", result);
            }

            //PGCD
            else if(operation == 'g'){
                printf("entrez le premier nombre :");
                scanf("%f",&nombre1);
                printf("entrez le segond nombre : ");
                scanf("%f",&nombre2);

                int pgcd = 0;
                int max = 0;
                int n1 = (int)nombre1;
                int n2 = (int)nombre2;

                if(n1 > n2){
                    max = n2;
                }
                else{
                    max = n1;
                }

                for( int i = 1; i <= max; i++){
                    if(n1%i == 0 && n2%i == 0){
                        pgcd = i;
                    }
                }

                printf("resultat : %d \n\n\n", pgcd);
            }

            //ppmc
            else if(operation == 'p'){
               printf("entrez le premier nombre :");
                scanf("%f",&nombre1);
                printf("entrez le segond nombre : ");
                scanf("%f",&nombre2);

                int ppmc = 0;
                int max = 0;
                int min = 0;
                int i = 1;

                int n1 = (int)nombre1;
                int n2 = (int)nombre2;

                if(n1 < n2){
                    max = n2;
                    min = n1;
                }
                else{
                    max = n1;
                    min = n2;
                }

                ppmc = max;

                while(ppmc % min != 0){
                    ppmc = max * i;
                    i++;
                }

                printf("resultat : %d \n\n\n", ppmc);

            }

            //quitter
            else if(operation == 'q'){
                on = false;
            }

            else{
                printf("operation non reconnu \n\n\n");
            }

    }

    return 0;
}
